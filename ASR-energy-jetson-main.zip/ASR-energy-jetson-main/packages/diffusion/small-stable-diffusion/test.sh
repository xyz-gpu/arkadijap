#!/usr/bin/env bash

cd /opt/small-stable-diffusion
python3 gpu-trt-infer-demo.py --help

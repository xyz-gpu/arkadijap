#!/usr/bin/env bash

cat /usr/local/cuda/version*

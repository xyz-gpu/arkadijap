#!/usr/bin/env bash

cd /opt/cuda-samples/bin/aarch64/linux/release

./deviceQuery
./bandwidthTest
./vectorAdd
./matrixMul
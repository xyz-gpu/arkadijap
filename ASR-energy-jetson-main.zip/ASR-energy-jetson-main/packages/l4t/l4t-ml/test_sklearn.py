
print('testing sklearn...')
import sklearn

print('sklearn version: ' + str(sklearn.__version__))

print('sklearn OK\n')

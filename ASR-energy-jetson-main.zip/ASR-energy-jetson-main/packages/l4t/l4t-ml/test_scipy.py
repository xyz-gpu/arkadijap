
print('testing scipy...')
import scipy

print('scipy version: ' + str(scipy.__version__))

print('scipy OK\n')


print('testing pandas...')
import pandas

print('pandas version: ' + str(pandas.__version__))
print(pandas.show_versions())

print('pandas OK\n')

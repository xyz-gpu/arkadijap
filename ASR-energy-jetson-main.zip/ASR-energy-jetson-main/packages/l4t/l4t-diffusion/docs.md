
<img src="https://raw.githubusercontent.com/dusty-nv/jetson-containers/docs/docs/images/diffusion_robots_lake.jpg">

Please refer to the documentation from the following packages:

* [`stable-diffusion`](/packages/diffusion/stable-diffusion)
* [`stable-diffusion-webui`](/packages/diffusion/stable-diffusion-webui)
    
By default, this container will automatically start the [`stable-diffusion-webui`](/packages/diffusion/stable-diffusion-webui) server (navigate your browser to `http://$IP_ADDRESS:7860`)
 
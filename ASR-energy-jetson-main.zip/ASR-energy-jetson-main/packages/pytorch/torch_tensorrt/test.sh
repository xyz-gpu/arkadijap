#!/usr/bin/env bash
set -e

echo "testing torch_tensorrt (torchtrtc)..."

torchtrtc --help

echo "torch_tensorrt (torchtrtc) OK"

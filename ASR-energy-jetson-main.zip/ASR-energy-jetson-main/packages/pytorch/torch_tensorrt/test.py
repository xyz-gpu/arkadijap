#!/usr/bin/env python3
print('testing torch_tensorrt...')

import torch_tensorrt

print('torch_tensorrt version:', torch_tensorrt.__version__)

print('torch_tensorrt OK\n')

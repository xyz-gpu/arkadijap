#!/usr/bin/env bash
set -e

echo "testing deepstream..."

deepstream-app --version

echo "deepstream OK"

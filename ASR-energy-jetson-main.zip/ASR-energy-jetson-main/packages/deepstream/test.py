#!/usr/bin/env python3
print('testing deepstream (pyds)...')

import pyds

print('deepstream (pyds) OK\n')

print('testing tensorrt_llm...')

import tensorrt_llm

print('tensorrt_llm OK')

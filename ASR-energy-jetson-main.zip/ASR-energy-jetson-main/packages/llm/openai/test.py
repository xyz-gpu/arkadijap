#!/usr/bin/env python3
import openai
from openai import OpenAI

print(f"OpenAI API version: {openai.__version__}")

#!/usr/bin/env python3
print('testing bitsandbytes...')

import bitsandbytes

print('bitsandbytes OK\n')

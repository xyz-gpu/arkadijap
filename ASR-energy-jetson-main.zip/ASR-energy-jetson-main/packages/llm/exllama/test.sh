#!/usr/bin/env bash

cd /opt/exllamav2
python3 test_inference.py --help

#!/usr/bin/env bash
echo "testing ollama"

ollama --help

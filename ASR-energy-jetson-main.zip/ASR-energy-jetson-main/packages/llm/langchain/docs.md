
* langchain from https://github.com/langchain-ai/langchain

The `langchain:samples` container has a default run command to launch Jupyter Lab with notebook directory to be `/opt/langchain`

Use your web browser to access `http://HOSTNAME:8888`
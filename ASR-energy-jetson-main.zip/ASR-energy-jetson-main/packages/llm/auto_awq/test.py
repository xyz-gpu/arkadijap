#!/usr/bin/env python3
print('testing AutoAWQ...')

import awq
from awq import AutoAWQForCausalLM

print('AutoAWQ OK\n')

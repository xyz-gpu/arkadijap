#!/usr/bin/env python3
from .server import WebServer
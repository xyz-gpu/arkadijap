#!/usr/bin/env python3
print('testing huggingface_hub...')

import huggingface_hub

print('huggingface_hub version:', huggingface_hub.__version__)

print('huggingface_hub OK\n')
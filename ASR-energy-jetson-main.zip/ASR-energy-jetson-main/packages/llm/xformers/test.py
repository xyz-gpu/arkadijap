#!/usr/bin/env python3
print('testing xformers...')

import xformers
import xformers.info

xformers.info.print_info()

print('xformers OK\n')


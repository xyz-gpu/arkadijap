#!/usr/bin/env python3
from llama_cpp import llama_print_system_info

llama_print_system_info()

#!/usr/bin/env python3
print('testing AutoGPTQ...')

import auto_gptq

print('AutoGPTQ OK\n')

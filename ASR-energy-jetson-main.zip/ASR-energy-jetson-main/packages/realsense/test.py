#!/usr/bin/env python3
print('testing pyrealsense2...')

import pyrealsense2 as rs
print('pyrealsense2 version:', rs.__version__)

print('pyrealsense2 OK\n')

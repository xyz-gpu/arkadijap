#!/usr/bin/env python3
print('testing numpy...')
import numpy as np

print('numpy version: ' + str(np.__version__))
print(np.show_config())

print('numpy OK\n')

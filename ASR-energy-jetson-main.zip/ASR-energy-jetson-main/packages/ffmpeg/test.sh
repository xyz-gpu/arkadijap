#!/usr/bin/env bash

set -e

ffmpeg -version

ffmpeg -encoders

ffmpeg -decoders

#!/usr/bin/env bash

echo "getting ROS version -"
echo $ROS_DISTRO

ros2 pkg list

#!/usr/bin/env bash

echo "getting ROS version -"
rosversion -d


Track Anything from https://github.com/gaomingqi/Track-Anything

The `tam` container has a default run command to launch its web server app.

Use your web browser to access `http://HOSTNAME:12212`


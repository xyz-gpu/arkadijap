#!/usr/bin/env python3
print('testing ZED (pyzed)...')

import pyzed

print('ZED (pyzed) OK\n')

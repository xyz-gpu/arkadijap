#!/usr/bin/env python3
print('testing onnx...')

import onnx

print('onnx version:', onnx.__version__)

print('onnx OK\n')

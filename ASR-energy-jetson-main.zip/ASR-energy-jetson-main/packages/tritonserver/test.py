#!/usr/bin/env python3
print('testing tritonserver...')

import tritonclient

print('tritonserver OK\n')

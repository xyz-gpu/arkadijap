print("testing psutil_home_assistant...")

import psutil_home_assistant

print("psutil_home_assistant OK")

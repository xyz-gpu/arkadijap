print("testing homeassistant...")

import homeassistant

print("homeassistant OK")

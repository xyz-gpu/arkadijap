package['build_args'] = {
    'BASHIO_VERSION': '0.16.2',
    'TEMPIO_VERSION': '2021.09.0',
    'S6_OVERLAY_VERSION': '3.1.6.2',
}
